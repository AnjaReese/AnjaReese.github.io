
#include <stdio.h>
#include <syscall.h>
#include <pthread.h>
#define _GNU_SOURCE
#include <unistd.h>

int main()
{
    pid_t tid = gettid();
    printf("LWP id is %d \n", tid);

    pthread_t pthread_tid = pthread_self();
    printf("POSIX thread id is %lu \n", pthread_tid);

    sleep(50);
    return 0;
}
