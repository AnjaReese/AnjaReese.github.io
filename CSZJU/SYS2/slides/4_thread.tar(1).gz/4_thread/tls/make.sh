gcc -o tls tls.c -m32 -lpthread
gcc -o tls1 tls1.c -m32 -lpthread
gcc -o tls1_nothread tls1_nothread.c -m32 -lpthread