rm lwp
rm process
