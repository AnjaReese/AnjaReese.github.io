#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include <sys/types.h>

#include <unistd.h>
#include <sys/syscall.h>



int x = 3;

void print_msg() {
	pid_t tid = syscall(SYS_gettid);
	printf("tid %lu x: %d   \n", (unsigned long)tid , x);
}

void *exec_in_thread(void *args) {
	
	x += 1;
	print_msg();

	sleep(3);
	pthread_exit(NULL);
}

int main() {
	int i = 0, num_threads = 10;
	pthread_t threads[num_threads];
	for(i = 0; i<num_threads; i++) {
		pthread_create(&threads[i], NULL, exec_in_thread, NULL);
	}
	for(i = 0; i<num_threads; i++) {
		pthread_join(threads[i], NULL);
	}
	return 0;
}
