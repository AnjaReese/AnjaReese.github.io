rm cow
