gcc -o lwp lwp.c -lpthread
gcc -o process process.c -lpthread