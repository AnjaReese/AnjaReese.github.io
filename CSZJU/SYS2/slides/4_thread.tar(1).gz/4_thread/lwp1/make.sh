gcc -o lwp1 lwp1.c -lpthread
